import React from 'react';
import { motion } from 'motion/react';
import { Globe, Lightbulb, Lock, Maximize, Target, Zap } from 'lucide-react';

export function About() {
  return (
    <div className="pt-24 pb-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.img 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            src="/logo-aeroscan.png" 
            alt="Aero Scan Original Logo" 
            className="w-32 h-32 object-contain mx-auto mb-8" 
          />
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white tracking-tight">Technology With Purpose</h1>
          <p className="text-xl text-slate-400">
            Aero Scan Kenya Ltd is a Kenyan technology company focused on developing practical digital platforms that solve real-world problems.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 mb-32">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-slate-900 border border-cyan-600/20 rounded-xl p-8 lg:p-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4">Our Mission</h2>
            <p className="text-slate-400 text-lg leading-relaxed">
              To build accessible, secure and intelligent technology that improves how people, businesses and institutions operate.
            </p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-slate-900 border border-cyan-600/20 rounded-xl p-8 lg:p-12"
          >
            <h2 className="text-2xl font-bold text-white mb-4">Our Vision</h2>
            <p className="text-slate-400 text-lg leading-relaxed">
              To become a leading African technology company building connected digital solutions for the future.
            </p>
          </motion.div>
        </div>

        <div className="mb-20">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white">Why Aero Scan</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Globe, title: 'AFRICAN-FIRST', desc: 'Technology designed with African realities in mind.' },
              { icon: Target, title: 'PRACTICAL', desc: 'Solutions focused on real problems.' },
              { icon: Zap, title: 'CONNECTED', desc: 'Products designed to work within larger ecosystems.' },
              { icon: Maximize, title: 'SCALABLE', desc: 'Architecture prepared for growth.' },
              { icon: Lock, title: 'SECURE', desc: 'Privacy and access control built into the architecture.' },
              { icon: Lightbulb, title: 'INNOVATIVE', desc: 'AI, cloud, mobile and emerging technologies.' },
            ].map((feature, i) => (
              <motion.div 
                key={feature.title}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="bg-slate-900 border border-cyan-600/20 p-8 rounded-xl hover:bg-slate-800 transition-colors"
              >
                <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center mb-6">
                  <feature.icon className="w-6 h-6 text-cyan-500" />
                </div>
                <h3 className="text-white font-bold tracking-wider mb-3">{feature.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
